# Dimensity 820 (MT6875) Network Mod

**Version:** v2.0 | **Author:** Elvan | **License:** MIT

**EXCLUSIVE:** Dimensity 820 (MT6875) only. Aborts on any other chip.

**Always-on max performance.** No profiles, no compromises.

---

## Dimensity 820 Specs

| | |
|---|---|
| **CPU** | 4x Cortex-A76 @ 2.6GHz + 4x Cortex-A55 @ 2.0GHz |
| **GPU** | Mali-G57 MC5 @ 900MHz |
| **Process** | TSMC 7nm |
| **5G Modem** | Integrated, Sub-6GHz, SA+NSA |
| **NR CA** | 2CC CA, 120MHz, 256QAM |
| **NR Speed** | 4.7Gbps DL / 2.3Gbps UL |
| **LTE** | Cat 18, 5CC CA, 256QAM, 4x4 MIMO |
| **WiFi** | Wi-Fi 6 (802.11ax), 2x2 MIMO, 80MHz (MT6631) |
| **Bluetooth** | 5.1 |

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│  LAYER 1 — Android Init (pre-userspace)             │
│  system/etc/init/mtk-bwmod.rc                       │
│  system/etc/sysctl.d/99-mtk-bwmod.conf              │
│  system/etc/dhcpcd/dhcpcd.conf                      │
│  system/etc/resolv.conf                             │
├─────────────────────────────────────────────────────┤
│  LAYER 2 — D820-Specific Properties                 │
│  system.prop (~120 props, NR Sub-6 only, MT6631)    │
├─────────────────────────────────────────────────────┤
│  LAYER 3 — Boot Service (always max performance)    │
│  service.sh (27 sections, 64MB BBR, A76 IRQ)        │
└─────────────────────────────────────────────────────┘

All layers run at maximum — always.
```

---

## System Files (Layer 1)

### `system/etc/init/mtk-bwmod.rc`
Android init script. Processed before Magisk service.sh.
- IPv6 accept_ra enabled (MT6875 modem handles IPv6 well)
- Conntrack scaled for D820 cellular multi-stream

### `system/etc/sysctl.d/99-mtk-bwmod.conf`
sysctl.d fallback. Mirrors init.rc — ensures coverage across ROMs.

### `system/etc/dhcpcd/dhcpcd.conf`
DHCP client optimization for MT6631 WiFi 6.

| Setting | Value | Effect |
|---------|-------|--------|
| `rapid_commit` | on | 1 RTT DHCP |
| `timeout` | 10s | Fast fail |
| `static dns` | 1.1.1.1 1.0.0.1 | Cloudflare override |
| `noarp` | on | Skip ARP probe |

---

## Properties (Layer 2)

**~120 D820-specific props.** All kernel/network params via system files.

| # | Section | D820 Specifics |
|---|---------|---------------|
| 1 | LTE Carrier Aggregation | 5CC CA, D820 bands (no 29,30) |
| 2 | MTK Baseband | MT6875 RIL tuning |
| 3 | Fast Dormancy | Disabled (modem latency advantage) |
| 4 | WiFi HAL | MT6631, 80MHz, 2x2 MIMO |
| 5 | Logging Off | All disabled |
| 6 | DNS | Cloudflare |
| 7 | NR / 5G | Sub-6 only (no mmWave), 2CC CA |
| 8 | ConnSys / IMS / DSDS | MT6875 coexist |
| 9 | LTE-A Bands | D820 certified bands |
| 9a | NR Bands | n1,n3,n5,n7,n8,n20,n28,n38,n40,n41,n77,n78 |
| 10 | VoLTE / VoNR | Full HD voice |
| 11 | Antenna / Diversity | 4RX DL, UL MCS boost |
| 12 | ConnAC WiFi | MT6631 only (connac2), 2x2 MIMO |
| 13 | IMS Stack | AMR-WB, EVS, Opus, SRVCC |
| 14 | Network Search + Modem | 7nm optimized |
| 15 | Settings UI Unlock | Full feature visibility |

---

## Boot Service (Layer 3) — Always Max Performance

`service.sh` — 27 sections, D820 8-core (4+4), runs on every boot.

| # | Section | Tuning |
|---|---------|--------|
| 1 | Radio + NR | Sub-6 only, NR re-apply |
| 2 | IMS/VoLTE/VoNR | Full stack |
| 3 | TCP/BBR | 64MB buffers, BBR |
| 4 | UDP/QUIC | 65K min |
| 5 | WiFi Runtime | MT6631, 2x2, 80MHz |
| 6 | DNS | All interfaces |
| 7 | IRQ Affinity | MT6875 IRQs → A76 cluster (f0) |
| 8 | Data Stall | Recovery enabled |
| 9 | txqueuelen + RPS | 3000 + A76 steering |
| 10 | Settings UI Unlock | 5G/VoLTE/WFC/ViLTE/APN |
| 11 | CCCI + CA | 5CC LTE, 4RX, MT6631 |
| 12 | Signal + Search | 7nm modem power |
| 13 | WiFi AP QoS | WMM/BA/BF/802.11kvr (2x2) |
| 14 | tc qdisc | fq |
| 15 | HW Offloading | GRO/GSO/TSO |
| 16 | XPS | TX → A76 cluster |
| 17 | NAPI | Budget 600 |
| 18 | schedutil | A76: up=0µs, down=500µs |
| 19 | RPS Flow Table | 32768 entries |
| 20 | IRQ Coalescing | 50µs / 32 frames |
| 21 | TCP Overhead | timestamps=0, ECN |
| 22 | Conntrack | 2M entries |
| 23 | Route Metric | WiFi primary, NR/LTE fallback |
| 24 | DSCP Marking | EF/VoIP, AF41/HTTP |
| 25 | wpa_cli | AP negotiation |
| 26 | iw | Driver params |
| 27 | NR Data Path | PDN rebuild + Reflective QoS |

---

## Fixed Performance Parameters

No profiles. These values are locked at boot:

| Parameter | Value |
|-----------|-------|
| TCP Buffers | 64MB |
| Congestion Control | BBR |
| qdisc | fq |
| IRQ Coalescing | 50µs / 32 frames |
| Conntrack Max | 2,000,000 |
| schedutil A76 up | 0µs (instant) |
| schedutil A76 down | 500µs |
| NAPI Budget | 600 |
| WiFi Power Save | OFF |
| Fast Dormancy | OFF |

---

## D820 Detection (customize.sh)

5 strict methods — aborts on non-D820:

| # | Method | Check |
|---|--------|-------|
| 1 | Board platform | `ro.board.platform` = `mt6875` |
| 2 | Vendor platform | `ro.vendor.mediatek.platform` = `MT6875` |
| 3 | SoC model | `ro.soc.model` = `Dimensity 820` |
| 4 | Chip name | `ro.chipname` = `MT6875` |
| 5 | Device Tree | `/proc/device-tree/compatible` contains `mt6875` |

---

## Requirements

| | |
|---|---|
| **SoC** | Dimensity 820 (MT6875) — **exclusively** |
| **Root** | Magisk v24+ or KernelSU |
| **Android** | 10+ |
| **ROM** | AOSP, MIUI, HyperOS, ColorOS, any custom ROM |

---

## Installation

1. Download `mtk_bwmod_d820_v2.0.zip`
2. Magisk → Modules → Install from storage
3. Reboot — max performance activated automatically

**Verify:**
```bash
adb shell cat /data/local/tmp/mtk_bwmod.log
```

---

## Module Structure

```
mtk_bwmod_d820_v2.0.zip
├── system.prop                    [~120 D820-specific props]
├── service.sh                     [27 sections, A76-optimized]
├── customize.sh                   [strict D820 detection]
├── module.prop                    [D820 metadata]
├── system/
│   └── etc/
│       ├── init/
│       │   └── mtk-bwmod.rc       [D820 init tuning]
│       ├── sysctl.d/
│       │   └── 99-mtk-bwmod.conf  [D820 kernel params]
│       ├── dhcpcd/
│       │   └── dhcpcd.conf        [MT6631 fast DHCP]
│       └── resolv.conf            [DNS fallback]
└── META-INF/
    └── com/google/android/
        ├── update-binary
        └── updater-script
```

---

## Log

```bash
# Boot service log
adb shell cat /data/local/tmp/mtk_bwmod.log

# Post-fs-data patch log
adb shell cat /data/local/tmp/mtk_bwmod_postfs.log
```

---

## Disclaimer

This module is built exclusively for Dimensity 820 (MT6875). It will refuse installation on any other chip. No profiles — always max performance. No hardware modification. Disable module and reboot to fully revert.

---

**Author:** Elvan | **License:** MIT
